﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Hardware;
using Android.Locations;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using AugmentedRealityCross.World;
using Location = Android.Locations.Location;

namespace AugmentedRealityCross.Droid
{
	[Activity (Label = "AugmentedRealityCross.Droid", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity, ILocationListener, ISensorEventListener
	{
	    public MainViewModel ViewModel { get; set; }

        private LocationManager locationManager;

        private SensorManager sensorManager;
	    private Sensor orientation;

        private RelativeLayout RootLayout { get; set; }

        protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

            ViewModel = new MainViewModel();

            var metrics = Resources.DisplayMetrics;
            var widthInDp = ConvertPixelsToDp(metrics.WidthPixels);
            var heightInDp = ConvertPixelsToDp(metrics.HeightPixels);

            ViewModel.UpdateWorld(metrics.WidthPixels, metrics.HeightPixels);

            RootLayout = this.FindViewById<RelativeLayout>(Resource.Id.myMainLayout);

            locationManager = GetSystemService(Context.LocationService) as LocationManager;
            locationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 50, 0, this);

            sensorManager = GetSystemService(Context.SensorService) as SensorManager;
            orientation= sensorManager?.GetDefaultSensor(SensorType.Orientation);
            sensorManager.RegisterListener(this,orientation, SensorDelay.Normal);

            PopulateWorld();
		}

        private int ConvertPixelsToDp(float pixelValue)
        {
            var dp = (int)((pixelValue) / Resources.DisplayMetrics.Density);
            return dp;
        }

        public override void OnConfigurationChanged(Configuration newConfig)
	    {
	        base.OnConfigurationChanged(newConfig);


	    }

	    public void OnLocationChanged(Location location)
	    {
	       ViewModel.UpdateWorldLocation(location.Latitude,location.Longitude);
	    }

	    public void OnProviderDisabled(string provider)
	    {
	    }

	    public void OnProviderEnabled(string provider)
	    {
	    }

	    public void OnStatusChanged(string provider, Availability status, Bundle extras)
	    {
	    }

	    public void OnAccuracyChanged(Sensor sensor, SensorStatus accuracy)
	    {
	    }


        private int Updating;
        public void OnSensorChanged(SensorEvent e)
	    {

            if (Interlocked.CompareExchange(ref Updating, 1, 0) == 1) return;
            RunOnUiThread(() =>
            {
                UpdateElementsOnScreen(e.Values[2],e.Values[1],e.Values[0]);
                Interlocked.Exchange(ref Updating, 0);
            });

        }

        private IDictionary<TextView, IWorldElement<Event>> events = new Dictionary<TextView, IWorldElement<Event>>();

        private void PopulateWorld()
        {
            var elements = ViewModel.WorldEvents;
            foreach (var evt in elements)
            {
                var tv = new TextView(this) { Text = evt.Element.Type};
                RootLayout.AddView(tv);

                events[tv] = evt;
                //        < Button
                //android: id = "@+id/ok"
                //android: layout_width = "wrap_content"
                //android: layout_height = "wrap_content"
                //android: layout_below = "@id/entry"
                //android: layout_alignParentRight = "true"
                //android: layout_marginLeft = "10dip"
                //android: text = "OK" />

                //         var tb = new TextBlock { Text = evt.Element.Type, DataContext = evt };
                //        LayoutRoot.Children.Add(tb);
            }

        }

        private void UpdateElementsOnScreen(float roll,float pitch,float yaw)
        {
            //var roll = reading.RollDegrees * Math.PI / 180.0;
            //var pitch = reading.PitchDegrees * Math.PI / 180.0;
            //var yaw = reading.YawDegrees * Math.PI / 180.0;
            var cnt = RootLayout.ChildCount;
            for (int i = 0; i < cnt; i++)
            {
                var fe = RootLayout.GetChildAt(i) as TextView;
                if (fe == null || fe.Height == 0 || fe.Width == 0) continue;
                //var element = fe.DataContext as IWorldElement<Event>;
                //if (element == null) continue;
                var element = events[fe];
                if (element == null) continue;

                var offset = ViewModel.CalculateScreenOffset(element, fe.Width, fe.Height, roll, pitch, yaw);
                fe.TranslationX = (float)offset.TranslateX;
                fe.TranslationY = (float)offset.TranslateY;
                fe.ScaleX = (float) offset.Scale;
                fe.ScaleY = (float)offset.Scale;

                //                RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(30, 40);
                //params.leftMargin = 50;
                //params.topMargin = 60;
                //                rl.addView(iv, params);

                //var offset = ViewModel.CalculateScreenOffset(element, fe.ActualWidth, fe.ActualHeight, roll, pitch, yaw);
                //fe.RenderTransform = new CompositeTransform
                //{
                //    TranslateX = offset.TranslateX,
                //    TranslateY = offset.TranslateY,
                //    ScaleX = offset.Scale,
                //    ScaleY = offset.Scale
                //};
            }
        }
    }
}


